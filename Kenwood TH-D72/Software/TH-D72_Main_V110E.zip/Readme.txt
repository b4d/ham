Firmware Copyrights
The title to and ownership of copyrights for firmware embedded in Kenwood product memories are reserved 
for JVCKENWOOD Corporation. Any modifying, reverse engineering, copying, reproducing or disclosing on an Internet 
website of the firmware is strictly prohibited without prior written consent of JVCKENWOOD Corporation. 
Furthermore, any reselling, assigning or transferring of the firmware is also strictly prohibited without 
embedding the firmware in Kenwood product memories.
